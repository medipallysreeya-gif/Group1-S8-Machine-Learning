document.addEventListener("DOMContentLoaded", () => {
  // Registration
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    registerForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = registerForm.name.value;
      const email = registerForm.email.value;
      const password = registerForm.password.value;
      const confirm = registerForm.confirm.value;

      if (password !== confirm) {
        alert("Passwords do not match!");
        return;
      }

      localStorage.setItem("user", JSON.stringify({name, email, password}));
      alert("Registration successful!");
      window.location.href = "login.html";
    });
  }

  // Login
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = loginForm.email.value;
      const password = loginForm.password.value;
      const user = JSON.parse(localStorage.getItem("user"));

      if (user && user.email === email && user.password === password) {
        alert("Login successful!");
        window.location.href = "dashboard.html";
      } else {
        alert("Invalid credentials!");
      }
    });
  }

  // Prediction (Dashboard)
  const predictionForm = document.getElementById("predictionForm");
  if (predictionForm) {
    predictionForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const glucose = parseFloat(predictionForm.glucose.value);
      const bp = parseFloat(predictionForm.bp.value);
      const bmi = parseFloat(predictionForm.bmi.value);
      const insulin = parseFloat(predictionForm.insulin.value);
      const age = parseFloat(predictionForm.age.value);
      const pregnancies = parseFloat(predictionForm.pregnancies.value);

      let risk = "";
      let precautions = "";

      if (glucose < 100 && bmi < 25 && bp < 80) {
        risk = "No Risk";
        precautions = "✅ Maintain a balanced diet and regular exercise.";
      } else if (glucose < 140 && bmi < 30) {
        risk = "Medium Risk";
        precautions = "⚠️ Monitor blood sugar, reduce sugar intake, and stay active.";
      } else {
        risk = "High Risk";
        precautions = "❌ Consult a doctor immediately and follow medical advice.";
      }

      document.getElementById("result").innerHTML = `
        <div class="risk-box ${risk.replace(" ", "-").toLowerCase()}">
          <h3>Risk Level: ${risk}</h3>
          <p>${precautions}</p>
        </div>
      `;
    });
  }
});
